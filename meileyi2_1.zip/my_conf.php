<?php
$tokenauthority='';
$fbpxid='';
$drop1_uid = '';

$oldprice = 1570;
$skidka = 20;
$price = 1249;

$geoTelMask = 'ua'; // kz + ru - ''
$isWhite= 'gray'; // for cloak
?>